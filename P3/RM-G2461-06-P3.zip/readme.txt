Grupo: 2461
Pareja: 06
Integrantes de la pareja:
	- Pablo Díez del Pozo
	- Alejandro Alcalá Álvarez
En la carpeta Doc se localiza la memoria de la práctica 3 y contiene todas las respuestas a las preguntas dadas en la plantilla de la memoria.
En la carpeta Code se encuentran dos archivos:
	- Regfile.conf: este archivo contiene todo el registro en el servidor, es decir, todos los usuarios que pueden acceder al servidor.
	- Regexroute.cong: este archivo contiene todo las expresiones regulares para poder hacer una llamada rápida a cualquier usuario 
	este en el servidor y tambien para probar los diferentes sonidos que tiene el servidor Yate para comprobar si funciona la comunicación
	entre cliente y servidor.
